
import ForumList from '../../forums/ForumList';

export default function Forums() {
  return (
    <main>
      <h2>Forums</h2>
      <ForumList />
    </main>
  );
}
