
export default function Messages() {
  return (
    <main>
      <h2>Messages</h2>
      <p>Direct and group messages will appear here.</p>
    </main>
  );
}
