
export default function Home() {
  return (
    <main>
      <h1>NovaSpace</h1>
      <p>A SpaceHey-inspired social network.</p>
    </main>
  );
}
