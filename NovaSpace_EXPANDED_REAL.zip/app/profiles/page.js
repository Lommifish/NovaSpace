
import ProfileCard from '../../profiles/ProfileCard';

export default function Profiles() {
  return (
    <main>
      <h2>Profiles</h2>
      <ProfileCard username="demo_user" />
    </main>
  );
}
