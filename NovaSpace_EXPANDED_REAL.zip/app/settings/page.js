
export default function Settings() {
  return (
    <main>
      <h2>Settings</h2>
      <p>Change username, birthday, privacy, and theme.</p>
    </main>
  );
}
