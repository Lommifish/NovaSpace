
import Link from 'next/link';

export default function Header() {
  return (
    <nav className="nav">
      <Link href="/">Home</Link>
      <Link href="/forums">Forums</Link>
      <Link href="/profiles">Profiles</Link>
      <Link href="/messages">Messages</Link>
      <Link href="/settings">Settings</Link>
    </nav>
  );
}
