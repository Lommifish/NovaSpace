
export const firebaseConfig = {
  apiKey: "YOUR_KEY",
  authDomain: "novaspace.firebaseapp.com",
  projectId: "novaspace"
};
