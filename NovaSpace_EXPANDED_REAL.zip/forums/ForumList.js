
export default function ForumList() {
  const forums = ['General', 'Music', 'Layouts', 'Advice', 'Groups'];
  return (
    <ul>
      {forums.map(f => <li key={f}>{f}</li>)}
    </ul>
  );
}
