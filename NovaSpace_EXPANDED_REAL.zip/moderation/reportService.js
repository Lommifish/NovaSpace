
export function reportContent(type, id, reason) {
  console.log('Reported', type, id, reason);
}
