
export default function ProfileCard({ username }) {
  return (
    <div className="card">
      <h3>{username}</h3>
      <p>Status: Online</p>
    </div>
  );
}
